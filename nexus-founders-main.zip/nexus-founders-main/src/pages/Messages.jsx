import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Loader2, Send, MessageSquare, ChevronLeft } from "lucide-react";
import { toast } from "sonner";

function makeConversationId(emailA, emailB, projectId = "") {
  const sorted = [emailA, emailB].sort();
  return `${sorted[0]}__${sorted[1]}${projectId ? `__${projectId}` : ""}`;
}

export default function Messages() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [conversations, setConversations] = useState([]);
  const [activeConv, setActiveConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  // Pre-fill from URL params (e.g. clicking "message" on investor/project)
  const urlParams = new URLSearchParams(window.location.search);
  const prefilledTo = urlParams.get("to");
  const prefilledName = urlParams.get("name");
  const prefilledProject = urlParams.get("project");
  const prefilledProjectTitle = urlParams.get("projectTitle");

  useEffect(() => {
    async function load() {
      const u = await base44.auth.me().catch(() => null);
      if (!u) { setLoading(false); return; }
      setUser(u);

      // If prefilled, open that conversation directly
      if (prefilledTo) {
        const convId = makeConversationId(u.email, prefilledTo, prefilledProject || "");
        const existing = await base44.entities.Message.filter({ conversation_id: convId }, "created_date", 100);
        setActiveConv({
          id: convId,
          other_email: prefilledTo,
          other_name: prefilledName || prefilledTo,
          project_title: prefilledProjectTitle || null,
          project_id: prefilledProject || null
        });
        setMessages(existing);
        setLoading(false);
        return;
      }

      // Load all conversations
      const sent = await base44.entities.Message.filter({ sender_email: u.email }, "-created_date", 200);
      const received = await base44.entities.Message.filter({ receiver_email: u.email }, "-created_date", 200);
      const all = [...sent, ...received];

      // Group by conversation_id
      const convMap = {};
      for (const m of all) {
        if (!convMap[m.conversation_id]) {
          const other = m.sender_email === u.email ? m.receiver_email : m.sender_email;
          convMap[m.conversation_id] = {
            id: m.conversation_id,
            other_email: other,
            other_name: other,
            project_title: m.project_title || null,
            last_message: m.content,
            last_date: m.created_date,
            unread: 0
          };
        }
        if (m.receiver_email === u.email && !m.read) {
          convMap[m.conversation_id].unread++;
        }
        if (new Date(m.created_date) > new Date(convMap[m.conversation_id].last_date)) {
          convMap[m.conversation_id].last_message = m.content;
          convMap[m.conversation_id].last_date = m.created_date;
        }
      }
      setConversations(Object.values(convMap).sort((a, b) => new Date(b.last_date) - new Date(a.last_date)));
      setLoading(false);
    }
    load();
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const openConversation = async (conv) => {
    setActiveConv(conv);
    const msgs = await base44.entities.Message.filter({ conversation_id: conv.id }, "created_date", 100);
    setMessages(msgs);
    // Mark unread as read
    for (const m of msgs) {
      if (m.receiver_email === user.email && !m.read) {
        await base44.entities.Message.update(m.id, { read: true });
      }
    }
    setConversations(prev => prev.map(c => c.id === conv.id ? { ...c, unread: 0 } : c));
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeConv) return;
    setSending(true);

    const msg = await base44.entities.Message.create({
      sender_email: user.email,
      receiver_email: activeConv.other_email,
      content: newMessage.trim(),
      conversation_id: activeConv.id,
      project_id: activeConv.project_id || "",
      project_title: activeConv.project_title || "",
      read: false
    });

    setMessages(prev => [...prev, msg]);
    setNewMessage("");
    setSending(false);

    // Update conversation list
    setConversations(prev => {
      const exists = prev.find(c => c.id === activeConv.id);
      if (exists) {
        return [{ ...exists, last_message: newMessage.trim(), last_date: new Date().toISOString() }, ...prev.filter(c => c.id !== activeConv.id)];
      }
      return [{ ...activeConv, last_message: newMessage.trim(), last_date: new Date().toISOString(), unread: 0 }, ...prev];
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-5 w-5 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen px-6 text-center">
        <MessageSquare className="h-10 w-10 text-muted-foreground mb-4" />
        <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-2">SIGN IN REQUIRED</p>
        <p className="text-sm text-muted-foreground">You need to be logged in to send messages.</p>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Sidebar — conversation list */}
      <div className={`w-full md:w-80 lg:w-96 border-r border-border flex flex-col ${activeConv ? "hidden md:flex" : "flex"}`}>
        <div className="px-5 py-4 border-b border-border">
          <h1 className="font-black text-xl tracking-tight text-foreground uppercase">Messages</h1>
          <p className="font-mono text-[10px] text-muted-foreground mt-0.5">PRIVATE CONVERSATIONS</p>
        </div>

        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <MessageSquare className="h-8 w-8 text-muted-foreground mb-3" />
              <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">NO MESSAGES YET</p>
              <p className="text-xs text-muted-foreground mt-2">Start a conversation from an idea or investor profile.</p>
            </div>
          ) : (
            conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => openConversation(conv)}
                className={`w-full text-left px-5 py-4 border-b border-border hover:bg-secondary/50 transition-colors ${
                  activeConv?.id === conv.id ? "bg-secondary/50 border-l-2 border-l-primary" : ""
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-foreground truncate">
                        {conv.other_name}
                      </span>
                      {conv.unread > 0 && (
                        <span className="flex-shrink-0 h-4 w-4 bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                          {conv.unread}
                        </span>
                      )}
                    </div>
                    {conv.project_title && (
                      <p className="font-mono text-[10px] tracking-wider text-primary uppercase truncate">
                        RE: {conv.project_title}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{conv.last_message}</p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Chat panel */}
      <div className={`flex-1 flex flex-col ${!activeConv ? "hidden md:flex" : "flex"}`}>
        {!activeConv ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <MessageSquare className="h-10 w-10 text-muted-foreground mb-4" />
            <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">SELECT A CONVERSATION</p>
          </div>
        ) : (
          <>
            {/* Chat header */}
            <div className="px-5 py-4 border-b border-border flex items-center gap-3">
              <button
                onClick={() => setActiveConv(null)}
                className="md:hidden text-muted-foreground hover:text-primary"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <div>
                <h2 className="font-bold text-foreground">{activeConv.other_name}</h2>
                {activeConv.project_title && (
                  <p className="font-mono text-[10px] tracking-wider text-primary uppercase">
                    RE: {activeConv.project_title}
                  </p>
                )}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {messages.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">Send your first message to start the conversation.</p>
                </div>
              )}
              {messages.map((m) => {
                const isMe = m.sender_email === user.email;
                return (
                  <div key={m.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[75%] px-4 py-3 ${
                      isMe ? "bg-primary text-primary-foreground" : "bg-card border border-border text-foreground"
                    }`}>
                      <p className="text-sm leading-relaxed">{m.content}</p>
                      <p className={`text-[10px] font-mono mt-1 ${isMe ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                        {new Date(m.created_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <form onSubmit={sendMessage} className="px-5 py-4 border-t border-border flex gap-3">
              <Input
                value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-background border-border text-foreground"
              />
              <button
                type="submit"
                disabled={sending || !newMessage.trim()}
                className="flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-5 py-2 hover:opacity-90 disabled:opacity-50 transition-opacity"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}