import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, TrendingUp, DollarSign, Target, Users } from "lucide-react";
import { toast } from "sonner";
import NexusFooter from "../components/NexusFooter";

const SECTORS = [
  "AI & Machine Learning", "FinTech", "HealthTech", "EdTech", "E-Commerce",
  "SaaS", "CleanTech", "FoodTech", "PropTech", "Logistics",
  "Social Impact", "Creative & Media", "Cybersecurity", "IoT & Hardware",
  "Physical Labor", "Other"
];

const STAGES = ["Idea", "Prototype", "MVP", "Growth", "Scaling"];

const AMOUNTS = ["£1k–£10k", "£10k–£50k", "£50k–£250k", "£250k–£1M", "$1M+"];

export default function LookingForInvestors() {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    startup_name: "",
    founder_name: "",
    email: "",
    sector: "",
    stage: "",
    amount_seeking: "",
    pitch: "",
    website: "",
  });

  const update = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await base44.integrations.Core.SendEmail({
      to: "hello@nexus.com",
      subject: `[INVESTOR REQUEST] ${form.startup_name} — ${form.amount_seeking}`,
      body: `Startup: ${form.startup_name}\nFounder: ${form.founder_name}\nEmail: ${form.email}\nSector: ${form.sector}\nStage: ${form.stage}\nAmount Seeking: ${form.amount_seeking}\nWebsite: ${form.website}\n\nPitch:\n${form.pitch}`
    });
    toast.success("Your investor request has been submitted!");
    setForm({ startup_name: "", founder_name: "", email: "", sector: "", stage: "", amount_seeking: "", pitch: "", website: "" });
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-12 pb-10 border-b border-border">
        <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-2">
          RAISE CAPITAL
        </p>
        <h1 className="text-4xl sm:text-6xl font-black tracking-[-0.04em] text-foreground uppercase leading-[0.95]">
          LOOKING FOR
          <br />
          <span className="text-primary">INVESTORS</span>
        </h1>
        <p className="mt-4 text-sm text-muted-foreground max-w-lg">
          Submit your startup profile and get matched with investors actively looking for opportunities like yours.
        </p>
      </section>

      {/* Stats bar */}
      <section className="border-b border-border px-6 lg:px-[10vw] py-8">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8">
          {[
            { icon: Users, label: "ACTIVE INVESTORS", value: "120+" },
            { icon: DollarSign, label: "CAPITAL AVAILABLE", value: "£5M+" },
            { icon: Target, label: "DEALS CLOSED", value: "34" },
            { icon: TrendingUp, label: "AVG TICKET SIZE", value: "£50k" },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label}>
              <Icon className="h-4 w-4 text-primary mb-2" />
              <p className="text-2xl font-black text-foreground">{value}</p>
              <p className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase mt-1">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Form */}
      <section className="px-6 lg:px-[10vw] py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24">

          {/* Left: Why submit */}
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              HOW IT WORKS
            </p>
            <div className="space-y-6">
              {[
                { num: "01", title: "Submit Your Profile", desc: "Fill out your startup details — sector, stage, and how much you're raising." },
                { num: "02", title: "Get Matched", desc: "We surface your opportunity to investors whose criteria align with your startup." },
                { num: "03", title: "Start Conversations", desc: "Interested investors will reach out via the platform's private messaging system." },
                { num: "04", title: "Close the Deal", desc: "Negotiate terms and build a relationship that goes beyond just capital." },
              ].map(({ num, title, desc }) => (
                <div key={num} className="flex gap-5 items-start">
                  <span className="font-mono text-2xl font-black text-primary/30 leading-none flex-shrink-0">{num}</span>
                  <div>
                    <p className="font-semibold text-foreground text-sm">{title}</p>
                    <p className="text-muted-foreground text-sm mt-1 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              SUBMIT YOUR STARTUP
            </p>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">STARTUP NAME *</label>
                  <Input required value={form.startup_name} onChange={e => update("startup_name", e.target.value)}
                    className="bg-background border-border text-foreground text-sm" placeholder="Acme Inc." />
                </div>
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">FOUNDER NAME *</label>
                  <Input required value={form.founder_name} onChange={e => update("founder_name", e.target.value)}
                    className="bg-background border-border text-foreground text-sm" placeholder="Jane Doe" />
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">EMAIL *</label>
                <Input required type="email" value={form.email} onChange={e => update("email", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" placeholder="jane@acme.com" />
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">WEBSITE</label>
                <Input value={form.website} onChange={e => update("website", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" placeholder="https://acme.com" />
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">SECTOR *</label>
                  <select required value={form.sector} onChange={e => update("sector", e.target.value)}
                    className="w-full bg-background border border-border text-foreground text-sm px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary">
                    <option value="">Select sector</option>
                    {SECTORS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">STAGE *</label>
                  <select required value={form.stage} onChange={e => update("stage", e.target.value)}
                    className="w-full bg-background border border-border text-foreground text-sm px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary">
                    <option value="">Select stage</option>
                    {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">AMOUNT SEEKING *</label>
                <select required value={form.amount_seeking} onChange={e => update("amount_seeking", e.target.value)}
                  className="w-full bg-background border border-border text-foreground text-sm px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary">
                  <option value="">Select range</option>
                  {AMOUNTS.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">YOUR PITCH *</label>
                <Textarea required value={form.pitch} onChange={e => update("pitch", e.target.value)}
                  rows={6} className="bg-background border-border text-foreground text-sm leading-relaxed"
                  placeholder="Describe your startup, traction so far, and why you're a great investment opportunity..." />
              </div>

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:opacity-90 transition-opacity disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-primary">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "SUBMIT TO INVESTORS"}
              </button>
            </form>
          </div>
        </div>
      </section>

      <NexusFooter />
    </div>
  );
}