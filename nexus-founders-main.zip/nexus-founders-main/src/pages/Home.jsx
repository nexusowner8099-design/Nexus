import HeroSection from "../components/HeroSection";
import SynergyFeed from "../components/SynergyFeed";
import NexusFooter from "../components/NexusFooter";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div>
      <HeroSection heroImage="https://media.base44.com/images/public/69cc43f320dfdbfad1d65c69/844e0f058_generated_02b47b89.png" />

      {/* Stats section */}
      <section className="border-t border-border">
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-border">
          {[
            { label: "ACTIVE IDEAS", value: "∞" },
            { label: "CATEGORIES", value: "15" },
            { label: "LOCAL MATCHING", value: "ON" },
            { label: "CONNECTIONS", value: "LIVE" },
          ].map((stat) => (
            <div key={stat.label} className="p-6 lg:p-10 text-center">
              <p className="text-3xl lg:text-5xl font-black text-foreground tracking-tight">
                {stat.value}
              </p>
              <p className="mt-2 font-mono text-[10px] tracking-[0.3em] text-muted-foreground uppercase">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Synergy Feed */}
      <section className="border-t border-border">
        <div className="px-6 lg:px-[10vw] py-20 lg:py-32">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-12 gap-4">
            <div>
              <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-3">
                THE SYNERGY FEED
              </p>
              <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-foreground uppercase">
                LATEST IDEAS
              </h2>
            </div>
            <Link
              to="/explore"
              className="inline-flex items-center gap-2 font-mono text-xs tracking-widest text-primary hover:underline underline-offset-4"
            >
              VIEW ALL
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </div>
        <SynergyFeed limit={6} />
      </section>

      {/* CTA Section */}
      <section className="border-t border-border">
        <div className="px-6 lg:px-[10vw] py-24 lg:py-40 text-center">
          <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
            READY TO LAUNCH?
          </p>
          <h2 className="text-4xl sm:text-6xl lg:text-8xl font-black tracking-[-0.05em] leading-[0.9] text-foreground uppercase mb-10">
            YOUR IDEA
            <br />
            NEEDS A <span className="text-primary">TEAM</span>
          </h2>
          <Link
            to="/create"
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-10 py-5 hover:opacity-90 transition-opacity focus:outline-none focus:ring-3 focus:ring-primary"
          >
            BROADCAST YOUR IDEA NOW
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* About image section */}
      <section className="relative h-[50vh] lg:h-[70vh] border-t border-border overflow-hidden">
        <img
          src="https://media.base44.com/images/public/69cc43f320dfdbfad1d65c69/a9bf8fc6b_generated_2038b246.png"
          alt="Brutalist co-working space with focused entrepreneur"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-background/70" />
        <div className="absolute inset-0 flex items-center justify-center px-6">
          <div className="text-center max-w-2xl">
            <p className="font-mono text-xs tracking-widest text-primary uppercase mb-4">
              THE PHILOSOPHY
            </p>
            <p className="text-xl lg:text-2xl text-foreground leading-relaxed font-light">
              Every great venture started with a conversation between two people 
              who shared a vision. Nexus makes that conversation happen — in your city, 
              on your terms.
            </p>
          </div>
        </div>
      </section>

      <NexusFooter />
    </div>
  );
}