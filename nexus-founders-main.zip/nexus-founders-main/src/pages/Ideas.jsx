import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import CategoryFilter from "../components/CategoryFilter";
import NexusFooter from "../components/NexusFooter";
import { Input } from "@/components/ui/input";
import { Loader2, Search, MapPin, ArrowUpRight, Plus } from "lucide-react";

export default function Ideas() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState(null);
  const [searchCity, setSearchCity] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      const data = category
        ? await base44.entities.Project.filter({ category, is_active: true }, "-created_date", 100)
        : await base44.entities.Project.filter({ is_active: true }, "-created_date", 100);
      setProjects(data);
      setLoading(false);
    }
    load();
  }, [category]);

  const filtered = searchCity
    ? projects.filter((p) => p.city?.toLowerCase().includes(searchCity.toLowerCase()))
    : projects;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-12 pb-10 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-2">
              THE SYNERGY FEED
            </p>
            <h1 className="text-4xl sm:text-5xl font-black tracking-[-0.04em] text-foreground uppercase">
              ALL IDEAS
            </h1>
            <p className="mt-2 text-muted-foreground text-sm max-w-md">
              Browse every business idea posted by founders. Filter by industry or location to find your match.
            </p>
          </div>
          <Link
            to="/create"
            className="self-start sm:self-auto inline-flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-6 py-3 hover:opacity-90 transition-opacity"
          >
            <Plus className="h-3 w-3" />
            POST YOUR IDEA
          </Link>
        </div>
      </section>

      {/* Filters */}
      <section className="px-6 lg:px-[10vw] py-6 border-b border-border space-y-4">
        <div className="relative max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchCity}
            onChange={(e) => setSearchCity(e.target.value)}
            placeholder="Filter by city..."
            className="pl-10 bg-background border-border text-foreground font-mono text-sm h-9"
          />
        </div>
        <CategoryFilter selected={category} onSelect={setCategory} />
      </section>

      {/* Grid */}
      <section className="px-6 lg:px-[10vw] py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-3">
              NO IDEAS FOUND
            </p>
            <Link to="/create" className="inline-flex items-center gap-2 text-primary font-mono text-xs hover:underline">
              Be the first — post your idea
            </Link>
          </div>
        ) : (
          <>
            <p className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase mb-6">
              {filtered.length} IDEA{filtered.length !== 1 ? "S" : ""} FOUND
            </p>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((p) => (
                <Link
                  key={p.id}
                  to={`/project/${p.id}`}
                  className="border border-border bg-card hover:border-primary transition-all group p-6 flex flex-col gap-4 focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-[10px] tracking-[0.25em] text-primary uppercase">
                      {p.category}
                    </span>
                    <span className="font-mono text-[10px] border border-border text-muted-foreground px-2 py-0.5">
                      {p.stage}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xl font-black tracking-tight text-foreground uppercase group-hover:text-primary transition-colors leading-tight">
                      {p.title}
                    </h3>
                    {p.short_pitch && (
                      <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2">
                        {p.short_pitch}
                      </p>
                    )}
                  </div>

                  {p.skills_needed?.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {p.skills_needed.slice(0, 3).map((s) => (
                        <span key={s} className="font-mono text-[10px] border border-border text-muted-foreground px-2 py-0.5">
                          {s}
                        </span>
                      ))}
                      {p.skills_needed.length > 3 && (
                        <span className="font-mono text-[10px] text-muted-foreground">
                          +{p.skills_needed.length - 3} more
                        </span>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-auto pt-3 border-t border-border">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span className="font-mono text-xs">{p.city}, {p.country}</span>
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </Link>
              ))}
            </div>
          </>
        )}
      </section>

      <NexusFooter />
    </div>
  );
}