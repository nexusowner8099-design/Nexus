import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import IdeaCard from "../components/IdeaCard";
import CategoryFilter from "../components/CategoryFilter";
import NexusFooter from "../components/NexusFooter";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";

export default function Explore() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState(null);
  const [searchCity, setSearchCity] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      let data;
      if (category) {
        data = await base44.entities.Project.filter(
          { category, is_active: true },
          "-created_date",
          50
        );
      } else {
        data = await base44.entities.Project.filter(
          { is_active: true },
          "-created_date",
          50
        );
      }
      setProjects(data);
      setLoading(false);
    }
    load();
  }, [category]);

  const filtered = searchCity
    ? projects.filter((p) =>
        p.city?.toLowerCase().includes(searchCity.toLowerCase())
      )
    : projects;

  return (
    <div>
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-20 pb-12 border-b border-border">
        <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-3">
          DISCOVER
        </p>
        <h1 className="text-4xl sm:text-6xl font-black tracking-[-0.05em] text-foreground uppercase">
          EXPLORE IDEAS
        </h1>
        <p className="mt-4 text-muted-foreground max-w-lg">
          Browse business ideas from founders in your area. Filter by category or search by city to find your perfect match.
        </p>
      </section>

      {/* Filters */}
      <section className="px-6 lg:px-[10vw] py-8 border-b border-border space-y-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchCity}
            onChange={(e) => setSearchCity(e.target.value)}
            placeholder="Search by city..."
            className="pl-10 bg-background border-border text-foreground font-mono text-sm"
          />
        </div>
        <CategoryFilter selected={category} onSelect={setCategory} />
      </section>

      {/* Results */}
      <section>
        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24 px-6">
            <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
              NO IDEAS FOUND
            </p>
            <p className="mt-2 text-muted-foreground">
              Try adjusting your filters or be the first to broadcast in this category.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {filtered.map((project) => (
              <IdeaCard key={project.id} project={project} />
            ))}
          </div>
        )}
      </section>

      <NexusFooter />
    </div>
  );
}