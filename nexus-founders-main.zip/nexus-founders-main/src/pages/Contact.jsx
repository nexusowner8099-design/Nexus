import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send, Mail, MapPin, MessageSquare, Phone } from "lucide-react";
import { toast } from "sonner";
import NexusFooter from "../components/NexusFooter";

export default function Contact() {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const update = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await base44.integrations.Core.SendEmail({
      to: "hello@nexus.com",
      subject: `[NEXUS CONTACT] ${form.subject}`,
      body: `From: ${form.name} <${form.email}>\n\n${form.message}`
    });
    toast.success("Message sent! We'll get back to you soon.");
    setForm({ name: "", email: "", subject: "", message: "" });
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-12 pb-10 border-b border-border">
        <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-2">
          GET IN TOUCH
        </p>
        <h1 className="text-4xl sm:text-5xl font-black tracking-[-0.04em] text-foreground uppercase">
          CONTACT US
        </h1>
        <p className="mt-2 text-sm text-muted-foreground max-w-md">
          Have a question, idea, or partnership proposal? We'd love to hear from you.
        </p>
      </section>

      <section className="px-6 lg:px-[10vw] py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24">

          {/* Left: Info */}
          <div className="space-y-10">
            <div>
              <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
                WHY REACH OUT?
              </p>
              <div className="space-y-4">
                {[
                  { icon: MessageSquare, title: "General Enquiries", desc: "Questions about how Nexus works or how to get started." },
                  { icon: Mail, title: "Partnerships", desc: "Interested in collaborating or promoting through Nexus." },
                  { icon: MapPin, title: "Report an Issue", desc: "Something not working? Let us know and we'll fix it fast." },
                  { icon: Phone, title: "Phone", desc: "(843) 653-8200" },
                ].map(({ icon: Icon, title, desc }) => (
                  <div key={title} className="border border-border p-5 flex gap-4 items-start">
                    <div className="flex-shrink-0 h-9 w-9 bg-primary/10 flex items-center justify-center">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{title}</p>
                      <p className="text-muted-foreground text-sm mt-0.5">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border pt-8">
              <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-4">
                RESPONSE TIME
              </p>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We aim to respond to all messages within <span className="text-foreground font-semibold">24–48 hours</span>. 
                For urgent matters, reach out directly through the private messaging system.
              </p>
            </div>
          </div>

          {/* Right: Form */}
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              SEND A MESSAGE
            </p>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">
                    YOUR NAME *
                  </label>
                  <Input required value={form.name} onChange={e => update("name", e.target.value)}
                    className="bg-background border-border text-foreground text-sm" placeholder="Jane Doe" />
                </div>
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">
                    EMAIL *
                  </label>
                  <Input required type="email" value={form.email} onChange={e => update("email", e.target.value)}
                    className="bg-background border-border text-foreground text-sm" placeholder="jane@example.com" />
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">
                  SUBJECT *
                </label>
                <Input required value={form.subject} onChange={e => update("subject", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" placeholder="What's on your mind?" />
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">
                  MESSAGE *
                </label>
                <Textarea required value={form.message} onChange={e => update("message", e.target.value)}
                  rows={7} className="bg-background border-border text-foreground text-sm leading-relaxed"
                  placeholder="Tell us everything..." />
              </div>

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:opacity-90 transition-opacity disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-primary">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : (
                  <><Send className="h-3 w-3" /> SEND MESSAGE</>
                )}
              </button>
            </form>
          </div>
        </div>
      </section>

      <NexusFooter />
    </div>
  );
}