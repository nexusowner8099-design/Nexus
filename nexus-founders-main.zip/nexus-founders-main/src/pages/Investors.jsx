import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import NexusFooter from "../components/NexusFooter";
import { Loader2, TrendingUp, MessageSquare, Plus, X, ExternalLink } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  "AI & Machine Learning", "FinTech", "HealthTech", "EdTech", "E-Commerce",
  "SaaS", "CleanTech", "FoodTech", "PropTech", "Logistics",
  "Social Impact", "Creative & Media", "Cybersecurity", "IoT & Hardware", "Other"
];
const STAGES = ["Idea", "Prototype", "MVP", "Growth", "Scaling"];
const TICKET_SIZES = ["£1k–£10k", "£10k–£50k", "£50k–£250k", "£250k–£1M", "$1M+"];

export default function Investors() {
  const navigate = useNavigate();
  const [investors, setInvestors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [focusInput, setFocusInput] = useState("");
  const [form, setForm] = useState({
    name: "", email: "", bio: "", ticket_size: "",
    investment_focus: [], stage_preference: [], location: "", linkedin_url: ""
  });
  const [user, setUser] = useState(null);

  useEffect(() => {
    async function load() {
      const [inv, u] = await Promise.all([
        base44.entities.InvestorProfile.filter({ is_active: true }, "-created_date", 50),
        base44.auth.me().catch(() => null)
      ]);
      setInvestors(inv);
      if (u) {
        setUser(u);
        setForm(prev => ({ ...prev, name: u.full_name || "", email: u.email || "" }));
      }
      setLoading(false);
    }
    load();
  }, []);

  const addFocus = () => {
    if (focusInput.trim() && !form.investment_focus.includes(focusInput.trim())) {
      setForm(prev => ({ ...prev, investment_focus: [...prev.investment_focus, focusInput.trim()] }));
    }
    setFocusInput("");
  };

  const toggleStage = (s) => {
    setForm(prev => ({
      ...prev,
      stage_preference: prev.stage_preference.includes(s)
        ? prev.stage_preference.filter(x => x !== s)
        : [...prev.stage_preference, s]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    await base44.entities.InvestorProfile.create({ ...form, is_active: true });
    toast.success("Your investor profile is live!");
    const updated = await base44.entities.InvestorProfile.filter({ is_active: true }, "-created_date", 50);
    setInvestors(updated);
    setShowForm(false);
    setSubmitting(false);
  };

  const startMessage = (investor) => {
    navigate(`/messages?to=${encodeURIComponent(investor.email)}&name=${encodeURIComponent(investor.name)}`);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-12 pb-10 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-2">
              CAPITAL NETWORK
            </p>
            <h1 className="text-4xl sm:text-5xl font-black tracking-[-0.04em] text-foreground uppercase">
              INVESTORS
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-md">
              Browse investors actively looking to fund early-stage ideas. Find the right capital partner in your area.
            </p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="self-start sm:self-auto inline-flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-6 py-3 hover:opacity-90 transition-opacity"
          >
            <Plus className="h-3 w-3" />
            LIST AS INVESTOR
          </button>
        </div>
      </section>

      {/* Register form */}
      {showForm && (
        <section className="px-6 lg:px-[10vw] py-10 border-b border-border bg-card">
          <div className="max-w-xl">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              YOUR INVESTOR PROFILE
            </p>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">NAME *</label>
                  <Input required value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))}
                    className="bg-background border-border text-foreground text-sm" />
                </div>
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">EMAIL *</label>
                  <Input required type="email" value={form.email} onChange={e => setForm(p => ({...p, email: e.target.value}))}
                    className="bg-background border-border text-foreground text-sm" />
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">BIO / INVESTMENT THESIS *</label>
                <Textarea required value={form.bio} onChange={e => setForm(p => ({...p, bio: e.target.value}))}
                  rows={3} className="bg-background border-border text-foreground text-sm" placeholder="What do you look for in a startup?" />
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">TICKET SIZE</label>
                  <Select value={form.ticket_size} onValueChange={v => setForm(p => ({...p, ticket_size: v}))}>
                    <SelectTrigger className="bg-background border-border text-foreground font-mono text-sm">
                      <SelectValue placeholder="Select range" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {TICKET_SIZES.map(t => <SelectItem key={t} value={t} className="font-mono text-sm">{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">LOCATION</label>
                  <Input value={form.location} onChange={e => setForm(p => ({...p, location: e.target.value}))}
                    className="bg-background border-border text-foreground text-sm" placeholder="London, UK" />
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">INVESTMENT FOCUS</label>
                <div className="flex gap-2 mb-2">
                  <Input value={focusInput} onChange={e => setFocusInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addFocus())}
                    className="bg-background border-border text-foreground text-sm flex-1" placeholder="e.g. FinTech, SaaS" />
                  <button type="button" onClick={addFocus}
                    className="border border-border px-3 font-mono text-xs text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                    ADD
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {form.investment_focus.map(f => (
                    <span key={f} className="inline-flex items-center gap-1.5 font-mono text-[10px] border border-primary text-primary px-2 py-1">
                      {f}
                      <button type="button" onClick={() => setForm(p => ({...p, investment_focus: p.investment_focus.filter(x => x !== f)}))}>
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">STAGE PREFERENCE</label>
                <div className="flex flex-wrap gap-2">
                  {STAGES.map(s => (
                    <button key={s} type="button" onClick={() => toggleStage(s)}
                      className={`font-mono text-[10px] tracking-wider uppercase px-3 py-1.5 border transition-all ${
                        form.stage_preference.includes(s)
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                      }`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase block mb-1.5">LINKEDIN URL</label>
                <Input value={form.linkedin_url} onChange={e => setForm(p => ({...p, linkedin_url: e.target.value}))}
                  className="bg-background border-border text-foreground text-sm" placeholder="https://linkedin.com/in/..." />
              </div>

              <button type="submit" disabled={submitting}
                className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:opacity-90 disabled:opacity-50">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "PUBLISH INVESTOR PROFILE →"}
              </button>
            </form>
          </div>
        </section>
      )}

      {/* Investor grid */}
      <section className="px-6 lg:px-[10vw] py-10">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </div>
        ) : investors.length === 0 ? (
          <div className="text-center py-20">
            <TrendingUp className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
            <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-2">NO INVESTORS YET</p>
            <p className="text-sm text-muted-foreground">Be the first investor to list your profile.</p>
          </div>
        ) : (
          <>
            <p className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase mb-6">
              {investors.length} INVESTOR{investors.length !== 1 ? "S" : ""} ACTIVE
            </p>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
              {investors.map((inv) => (
                <div key={inv.id} className="border border-border bg-card p-6 flex flex-col gap-4">
                  {/* Top */}
                  <div className="flex items-start justify-between">
                    <div className="h-10 w-10 bg-secondary flex items-center justify-center font-black text-lg text-foreground">
                      {inv.name?.charAt(0).toUpperCase()}
                    </div>
                    {inv.ticket_size && (
                      <span className="font-mono text-[10px] tracking-widest text-primary border border-primary px-2 py-1 uppercase">
                        {inv.ticket_size}
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-foreground">{inv.name}</h3>
                    {inv.location && (
                      <p className="font-mono text-xs text-muted-foreground mt-0.5">{inv.location}</p>
                    )}
                    <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-3">{inv.bio}</p>
                  </div>

                  {inv.investment_focus?.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {inv.investment_focus.map(f => (
                        <span key={f} className="font-mono text-[10px] border border-border text-muted-foreground px-2 py-0.5">{f}</span>
                      ))}
                    </div>
                  )}

                  {inv.stage_preference?.length > 0 && (
                    <div>
                      <p className="font-mono text-[10px] tracking-wider text-muted-foreground uppercase mb-1.5">STAGES</p>
                      <div className="flex flex-wrap gap-1.5">
                        {inv.stage_preference.map(s => (
                          <span key={s} className="font-mono text-[10px] border border-border text-muted-foreground px-2 py-0.5">{s}</span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 mt-auto pt-4 border-t border-border">
                    <button
                      onClick={() => startMessage(inv)}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-primary text-primary-foreground font-mono text-[10px] tracking-widest uppercase py-2.5 hover:opacity-90 transition-opacity"
                    >
                      <MessageSquare className="h-3 w-3" />
                      MESSAGE
                    </button>
                    {inv.linkedin_url && (
                      <a href={inv.linkedin_url} target="_blank" rel="noopener noreferrer"
                        className="flex items-center justify-center border border-border text-muted-foreground hover:border-primary hover:text-primary transition-colors px-3">
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      <NexusFooter />
    </div>
  );
}