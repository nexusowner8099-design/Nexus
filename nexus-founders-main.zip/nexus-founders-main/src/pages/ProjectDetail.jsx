import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import SynergyPitchForm from "../components/SynergyPitchForm";
import { Loader2, ArrowLeft, MapPin, User, Layers, MessageSquare } from "lucide-react";

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.Project.filter({ id });
      if (data.length > 0) setProject(data[0]);
      setLoading(false);
    }
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen px-6">
        <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-4">
          PROJECT NOT FOUND
        </p>
        <Link
          to="/explore"
          className="inline-flex items-center gap-2 text-primary font-mono text-xs tracking-widest hover:underline"
        >
          <ArrowLeft className="h-3 w-3" />
          BACK TO EXPLORE
        </Link>
      </div>
    );
  }

  return (
    <div>
      {/* Back button */}
      <div className="px-6 lg:px-[10vw] pt-8">
        <Link
          to="/explore"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary font-mono text-xs tracking-widest transition-colors"
        >
          <ArrowLeft className="h-3 w-3" />
          BACK
        </Link>
      </div>

      {/* Project header */}
      <section className="px-6 lg:px-[10vw] pt-12 pb-16 border-b border-border">
        <div className="flex flex-wrap items-center gap-4 mb-6">
          <span className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase">
            {project.category}
          </span>
          <span className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase border border-border px-2 py-1">
            {project.stage}
          </span>
        </div>
        <h1 className="text-4xl sm:text-6xl lg:text-8xl font-black tracking-[-0.05em] leading-[0.9] text-foreground uppercase">
          {project.title}
        </h1>
        {project.short_pitch && (
          <p className="mt-6 text-xl text-muted-foreground max-w-2xl leading-relaxed">
            {project.short_pitch}
          </p>
        )}
      </section>

      {/* 3-column layout */}
      <section className="px-6 lg:px-[10vw] py-16 lg:py-24">
        <div className="grid lg:grid-cols-3 gap-12 lg:gap-16">
          {/* Column 1: Vision */}
          <div className="lg:col-span-1">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              THE VISION
            </p>
            <p className="text-foreground leading-[1.8] whitespace-pre-wrap">
              {project.description}
            </p>

            {project.skills_needed?.length > 0 && (
              <div className="mt-10">
                <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-4">
                  SKILLS NEEDED
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.skills_needed.map((skill) => (
                    <span
                      key={skill}
                      className="font-mono text-xs tracking-wider border border-border text-muted-foreground px-3 py-1.5"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Column 2: Founder */}
          <div className="lg:col-span-1">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              THE FOUNDER
            </p>
            <div className="border border-border p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 bg-secondary flex items-center justify-center">
                  <User className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    {project.founder_name}
                  </p>
                  <p className="font-mono text-xs text-muted-foreground">
                    {project.founder_email}
                  </p>
                </div>
              </div>

              {project.founder_bio && (
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {project.founder_bio}
                </p>
              )}

              <div className="pt-4 border-t border-border space-y-2">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  <span className="font-mono text-xs tracking-wider">
                    {project.city}{project.zip_code ? `, ${project.zip_code}` : ""}, {project.country}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Layers className="h-3 w-3" />
                  <span className="font-mono text-xs tracking-wider">
                    Stage: {project.stage}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Column 3: Contact form */}
          <div className="lg:col-span-1">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-6">
              THE BRIDGE — CONNECT
            </p>

            {/* Private message button */}
            <button
              onClick={() => navigate(`/messages?to=${encodeURIComponent(project.founder_email)}&name=${encodeURIComponent(project.founder_name)}&project=${project.id}&projectTitle=${encodeURIComponent(project.title)}`)}
              className="w-full mb-4 flex items-center justify-center gap-2 border border-primary text-primary font-mono text-xs tracking-widest uppercase px-6 py-3 hover:bg-primary hover:text-primary-foreground transition-all"
            >
              <MessageSquare className="h-3 w-3" />
              PRIVATE MESSAGE FOUNDER
            </button>

            <div className="border border-border p-6">
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                This is a high-intent form. Tell the founder exactly why you're the right person to collaborate with. Generic messages will be filtered.
              </p>
              <SynergyPitchForm projectId={project.id} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}