import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Zap } from "lucide-react";
import { toast } from "sonner";
import NexusFooter from "../components/NexusFooter";

const CATEGORIES = [
  "AI & Machine Learning", "FinTech", "HealthTech", "EdTech", "E-Commerce",
  "SaaS", "CleanTech", "FoodTech", "PropTech", "Logistics",
  "Social Impact", "Creative & Media", "Cybersecurity", "IoT & Hardware", "Other"
];

const STAGES = ["Idea", "Prototype", "MVP", "Growth", "Scaling"];

export default function CreateProject() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({
    title: "", category: "", description: "", short_pitch: "",
    skills_needed: "", city: "", zip_code: "", country: "", stage: "",
    founder_name: "", founder_email: "", founder_bio: ""
  });

  useEffect(() => {
    async function loadUser() {
      const u = await base44.auth.me();
      setUser(u);
      setForm(prev => ({
        ...prev,
        founder_name: u.full_name || "",
        founder_email: u.email || ""
      }));
    }
    loadUser();
  }, []);

  const update = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    await base44.entities.Project.create({
      ...form,
      skills_needed: form.skills_needed.split(",").map(s => s.trim()).filter(Boolean),
      is_active: true
    });

    toast.success("Your idea has been broadcast!");
    navigate("/explore");
  };

  return (
    <div>
      <section className="px-6 lg:px-[10vw] pt-20 pb-12 border-b border-border">
        <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-3">
          <Zap className="inline h-3 w-3 mr-1" />
          BROADCAST
        </p>
        <h1 className="text-4xl sm:text-6xl font-black tracking-[-0.05em] text-foreground uppercase">
          SHARE YOUR IDEA
        </h1>
        <p className="mt-4 text-muted-foreground max-w-lg">
          Put your business idea on the map. Let founders in your area find you and build something extraordinary together.
        </p>
      </section>

      <section className="px-6 lg:px-[10vw] py-16 lg:py-24">
        <form onSubmit={handleSubmit} className="max-w-2xl space-y-10">
          {/* Section: The Idea */}
          <div className="space-y-6">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase border-b border-border pb-3">
              01 — THE IDEA
            </p>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">TITLE *</label>
              <Input required value={form.title} onChange={(e) => update("title", e.target.value)}
                className="bg-background border-border text-foreground text-lg font-semibold" placeholder="AI-Driven Local Logistics" />
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">CATEGORY *</label>
              <Select required value={form.category} onValueChange={(v) => update("category", v)}>
                <SelectTrigger className="bg-background border-border text-foreground font-mono text-sm">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {CATEGORIES.map(c => (
                    <SelectItem key={c} value={c} className="font-mono text-sm">{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">ONE-LINE PITCH</label>
              <Input value={form.short_pitch} onChange={(e) => update("short_pitch", e.target.value)}
                className="bg-background border-border text-foreground text-sm" placeholder="Uber for local B2B deliveries" />
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">FULL DESCRIPTION *</label>
              <Textarea required value={form.description} onChange={(e) => update("description", e.target.value)}
                rows={8} className="bg-background border-border text-foreground text-sm leading-relaxed"
                placeholder="Describe your vision in detail. What problem are you solving? Why now? What's unique about your approach?" />
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">STAGE *</label>
              <Select required value={form.stage} onValueChange={(v) => update("stage", v)}>
                <SelectTrigger className="bg-background border-border text-foreground font-mono text-sm">
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {STAGES.map(s => (
                    <SelectItem key={s} value={s} className="font-mono text-sm">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">SKILLS NEEDED</label>
              <Input value={form.skills_needed} onChange={(e) => update("skills_needed", e.target.value)}
                className="bg-background border-border text-foreground text-sm" placeholder="Lead Developer, UX Designer, Growth Hacker" />
              <p className="mt-1 font-mono text-[10px] text-muted-foreground">Comma-separated</p>
            </div>
          </div>

          {/* Section: Location */}
          <div className="space-y-6">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase border-b border-border pb-3">
              02 — LOCATION
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">CITY *</label>
                <Input required value={form.city} onChange={(e) => update("city", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" placeholder="London" />
              </div>
              <div>
                <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">ZIP / POSTAL CODE</label>
                <Input value={form.zip_code} onChange={(e) => update("zip_code", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" placeholder="EC1A 1BB" />
              </div>
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">COUNTRY *</label>
              <Input required value={form.country} onChange={(e) => update("country", e.target.value)}
                className="bg-background border-border text-foreground text-sm" placeholder="United Kingdom" />
            </div>
          </div>

          {/* Section: Founder */}
          <div className="space-y-6">
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase border-b border-border pb-3">
              03 — THE FOUNDER
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">YOUR NAME *</label>
                <Input required value={form.founder_name} onChange={(e) => update("founder_name", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" />
              </div>
              <div>
                <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">YOUR EMAIL *</label>
                <Input required type="email" value={form.founder_email} onChange={(e) => update("founder_email", e.target.value)}
                  className="bg-background border-border text-foreground text-sm" />
              </div>
            </div>

            <div>
              <label className="font-mono text-[10px] tracking-[0.3em] text-foreground uppercase block mb-2">SHORT BIO</label>
              <Textarea value={form.founder_bio} onChange={(e) => update("founder_bio", e.target.value)}
                rows={3} className="bg-background border-border text-foreground text-sm leading-relaxed"
                placeholder="Your background, expertise, and what drives you." />
            </div>
          </div>

          <button type="submit" disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-5 hover:opacity-90 transition-opacity disabled:opacity-50 focus:outline-none focus:ring-3 focus:ring-primary">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "BROADCAST MY IDEA →"}
          </button>
        </form>
      </section>

      <NexusFooter />
    </div>
  );
}