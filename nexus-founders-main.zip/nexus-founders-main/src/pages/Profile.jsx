import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { Loader2, User, MapPin, Layers, ArrowUpRight, Inbox, LogOut } from "lucide-react";
import NexusFooter from "../components/NexusFooter";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("projects");

  useEffect(() => {
    async function load() {
      const u = await base44.auth.me();
      setUser(u);

      const myProjects = await base44.entities.Project.filter(
        { created_by: u.email },
        "-created_date",
        50
      );
      setProjects(myProjects);

      // Load connections for my projects
      const allConnections = [];
      for (const p of myProjects) {
        const conns = await base44.entities.Connection.filter(
          { project_id: p.id },
          "-created_date",
          50
        );
        allConnections.push(...conns.map(c => ({ ...c, project_title: p.title })));
      }
      setConnections(allConnections);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <section className="px-6 lg:px-[10vw] pt-20 pb-12 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 bg-secondary flex items-center justify-center">
              <User className="h-7 w-7 text-muted-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-foreground uppercase">
                {user?.full_name || "ANONYMOUS"}
              </h1>
              <p className="font-mono text-xs text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={() => base44.auth.logout()}
            className="font-mono text-xs tracking-widest text-muted-foreground hover:text-primary transition-colors flex items-center gap-2"
          >
            <LogOut className="h-3 w-3" />
            LOGOUT
          </button>
        </div>
      </section>

      {/* Tabs */}
      <section className="px-6 lg:px-[10vw] border-b border-border">
        <div className="flex gap-0">
          {[
            { key: "projects", label: `MY IDEAS (${projects.length})` },
            { key: "connections", label: `PITCHES RECEIVED (${connections.length})` },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`font-mono text-[10px] tracking-widest uppercase px-6 py-4 border-b-2 transition-colors ${
                tab === t.key
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </section>

      {/* Content */}
      <section className="px-6 lg:px-[10vw] py-12 min-h-[50vh]">
        {tab === "projects" && (
          <div>
            {projects.length === 0 ? (
              <div className="text-center py-16">
                <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-4">
                  NO IDEAS YET
                </p>
                <Link
                  to="/create"
                  className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-6 py-3"
                >
                  BROADCAST YOUR FIRST IDEA
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {projects.map((p) => (
                  <Link
                    key={p.id}
                    to={`/project/${p.id}`}
                    className="flex items-center justify-between border border-border p-6 hover:border-primary transition-colors group"
                  >
                    <div>
                      <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase mb-1">
                        {p.category}
                      </p>
                      <h3 className="text-xl font-bold tracking-tight text-foreground uppercase group-hover:text-primary transition-colors">
                        {p.title}
                      </h3>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="flex items-center gap-1 font-mono text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3" /> {p.city}
                        </span>
                        <span className="flex items-center gap-1 font-mono text-xs text-muted-foreground">
                          <Layers className="h-3 w-3" /> {p.stage}
                        </span>
                      </div>
                    </div>
                    <ArrowUpRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "connections" && (
          <div>
            {connections.length === 0 ? (
              <div className="text-center py-16">
                <Inbox className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
                <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
                  NO PITCHES YET
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {connections.map((c) => (
                  <div key={c.id} className="border border-border p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase">
                        RE: {c.project_title}
                      </p>
                      <span className={`font-mono text-[10px] tracking-widest uppercase px-2 py-1 border ${
                        c.status === "accepted" ? "border-green-500 text-green-500" :
                        c.status === "declined" ? "border-red-500 text-red-500" :
                        "border-border text-muted-foreground"
                      }`}>
                        {c.status}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{c.sender_name}</p>
                      <p className="font-mono text-xs text-muted-foreground">{c.sender_email}</p>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {c.synergy_pitch}
                    </p>
                    {c.skills_offered?.length > 0 && (
                      <div className="flex flex-wrap gap-2 pt-2">
                        {c.skills_offered.map((s) => (
                          <span key={s} className="font-mono text-[10px] border border-border text-muted-foreground px-2 py-1">
                            {s}
                          </span>
                        ))}
                      </div>
                    )}

                    {c.status === "pending" && (
                      <div className="flex gap-3 pt-3 border-t border-border">
                        <button
                          onClick={async () => {
                            await base44.entities.Connection.update(c.id, { status: "accepted" });
                            setConnections(prev => prev.map(x => x.id === c.id ? { ...x, status: "accepted" } : x));
                          }}
                          className="font-mono text-[10px] tracking-widest uppercase px-4 py-2 bg-primary text-primary-foreground hover:opacity-90"
                        >
                          ACCEPT
                        </button>
                        <button
                          onClick={async () => {
                            await base44.entities.Connection.update(c.id, { status: "declined" });
                            setConnections(prev => prev.map(x => x.id === c.id ? { ...x, status: "declined" } : x));
                          }}
                          className="font-mono text-[10px] tracking-widest uppercase px-4 py-2 border border-border text-muted-foreground hover:border-destructive hover:text-destructive"
                        >
                          DECLINE
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </section>

      <NexusFooter />
    </div>
  );
}