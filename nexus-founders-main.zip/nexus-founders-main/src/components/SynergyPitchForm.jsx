import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send } from "lucide-react";
import { toast } from "sonner";

export default function SynergyPitchForm({ projectId, onSuccess }) {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    sender_name: "",
    sender_email: "",
    synergy_pitch: "",
    skills_offered: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    await base44.entities.Connection.create({
      project_id: projectId,
      sender_name: form.sender_name,
      sender_email: form.sender_email,
      synergy_pitch: form.synergy_pitch,
      skills_offered: form.skills_offered
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      status: "pending",
    });

    toast.success("Your synergy pitch has been sent!");
    setForm({ sender_name: "", sender_email: "", synergy_pitch: "", skills_offered: "" });
    setLoading(false);
    onSuccess?.();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase block mb-2">
          YOUR NAME
        </label>
        <Input
          required
          value={form.sender_name}
          onChange={(e) => setForm({ ...form, sender_name: e.target.value })}
          className="bg-background border-border text-foreground font-mono text-sm focus:ring-primary"
          placeholder="Jane Doe"
        />
      </div>

      <div>
        <label className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase block mb-2">
          YOUR EMAIL
        </label>
        <Input
          required
          type="email"
          value={form.sender_email}
          onChange={(e) => setForm({ ...form, sender_email: e.target.value })}
          className="bg-background border-border text-foreground font-mono text-sm focus:ring-primary"
          placeholder="jane@example.com"
        />
      </div>

      <div>
        <label className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase block mb-2">
          SKILLS YOU BRING
        </label>
        <Input
          value={form.skills_offered}
          onChange={(e) => setForm({ ...form, skills_offered: e.target.value })}
          className="bg-background border-border text-foreground font-mono text-sm focus:ring-primary"
          placeholder="React, Product Design, Growth Marketing"
        />
        <p className="mt-1 font-mono text-[10px] text-muted-foreground">
          Comma-separated
        </p>
      </div>

      <div>
        <label className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase block mb-2">
          SYNERGY PITCH *
        </label>
        <Textarea
          required
          value={form.synergy_pitch}
          onChange={(e) => setForm({ ...form, synergy_pitch: e.target.value })}
          rows={5}
          className="bg-background border-border text-foreground text-sm leading-relaxed focus:ring-primary"
          placeholder="Why do you want to collaborate on this idea? What unique value do you bring? Be specific — this is your first impression."
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:opacity-90 transition-opacity disabled:opacity-50 focus:outline-none focus:ring-3 focus:ring-primary"
      >
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <>
            SEND SYNERGY PITCH
            <Send className="h-4 w-4" />
          </>
        )}
      </button>
    </form>
  );
}