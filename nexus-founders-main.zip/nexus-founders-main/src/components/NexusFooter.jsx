import { Link } from "react-router-dom";
import { Zap } from "lucide-react";

export default function NexusFooter() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="px-6 lg:px-[10vw] py-24 lg:py-40">
        {/* Big statement */}
        <div className="mb-16">
          <h2 className="text-4xl sm:text-6xl lg:text-8xl font-black tracking-[-0.05em] leading-[0.9] text-foreground uppercase">
            IDEAS ARE
            <br />
            <span className="text-primary">STRONGER</span>
            <br />
            TOGETHER
          </h2>
        </div>

        {/* Links grid */}
        <div className="grid sm:grid-cols-3 gap-12 border-t border-border pt-12">
          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary mb-4 uppercase">
              NAVIGATE
            </p>
            <div className="space-y-3">
              <Link to="/" className="block font-mono text-xs tracking-wider text-muted-foreground hover:text-primary transition-colors">
                HOME
              </Link>
              <Link to="/explore" className="block font-mono text-xs tracking-wider text-muted-foreground hover:text-primary transition-colors">
                EXPLORE IDEAS
              </Link>
              <Link to="/create" className="block font-mono text-xs tracking-wider text-muted-foreground hover:text-primary transition-colors">
                BROADCAST IDEA
              </Link>
            </div>
          </div>

          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary mb-4 uppercase">
              THE ENGINE
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Nexus collapses the distance between vision and execution. 
              Find your co-founder, build your team, launch your venture — all within your local ecosystem.
            </p>
          </div>

          <div>
            <p className="font-mono text-[10px] tracking-[0.3em] text-primary mb-4 uppercase">
              IDENTITY
            </p>
            <div className="flex items-center gap-2 mb-3">
              <Zap className="h-4 w-4 text-primary" />
              <span className="font-mono text-sm font-semibold tracking-widest text-foreground uppercase">
                NEXUS
              </span>
            </div>
            <p className="font-mono text-[10px] tracking-wider text-muted-foreground">
              THE VENTURE ENGINE
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-mono text-[10px] tracking-wider text-muted-foreground">
            © {new Date().getFullYear()} NEXUS. ALL RIGHTS RESERVED.
          </p>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 bg-primary animate-pulse-slow" />
            <span className="font-mono text-[10px] tracking-wider text-muted-foreground">
              CONNECTIONS HAPPENING NOW
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}