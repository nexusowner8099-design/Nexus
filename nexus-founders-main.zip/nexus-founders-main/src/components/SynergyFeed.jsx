import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import IdeaCard from "./IdeaCard";
import { Loader2 } from "lucide-react";

export default function SynergyFeed({ limit = 6 }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const data = await base44.entities.Project.list("-created_date", limit);
      setProjects(data);
      setLoading(false);
    }
    load();
  }, [limit]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <div className="text-center py-24 px-6">
        <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
          NO IDEAS BROADCAST YET
        </p>
        <p className="mt-2 text-muted-foreground">
          Be the first to broadcast your vision.
        </p>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
      {projects.map((project) => (
        <IdeaCard key={project.id} project={project} />
      ))}
    </div>
  );
}