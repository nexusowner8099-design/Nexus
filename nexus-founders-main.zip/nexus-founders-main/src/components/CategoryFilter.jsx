const CATEGORIES = [
  "All",
  "AI & Machine Learning",
  "FinTech",
  "HealthTech",
  "EdTech",
  "E-Commerce",
  "SaaS",
  "CleanTech",
  "FoodTech",
  "PropTech",
  "Logistics",
  "Social Impact",
  "Creative & Media",
  "Cybersecurity",
  "IoT & Hardware",
  "Physical Labor",
  "Other",
];

export default function CategoryFilter({ selected, onSelect }) {
  return (
    <div className="flex flex-wrap gap-2">
      {CATEGORIES.map((cat) => (
        <button
          key={cat}
          onClick={() => onSelect(cat === "All" ? null : cat)}
          className={`font-mono text-[10px] tracking-widest uppercase px-4 py-2 border transition-all focus:outline-none focus:ring-3 focus:ring-primary ${
            (cat === "All" && !selected) || selected === cat
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted-foreground hover:border-primary hover:text-primary"
          }`}
        >
          {cat}
        </button>
      ))}
    </div>
  );
}