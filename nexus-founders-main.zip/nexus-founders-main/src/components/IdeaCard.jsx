import { Link } from "react-router-dom";
import { MapPin, ArrowUpRight } from "lucide-react";
import { useState } from "react";

export default function IdeaCard({ project }) {
  const [hovered, setHovered] = useState(false);

  return (
    <Link
      to={`/project/${project.id}`}
      className="block border border-border bg-card hover:border-primary transition-all duration-300 group focus:outline-none focus:ring-3 focus:ring-primary"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="p-6 lg:p-8 relative overflow-hidden">
        {/* Blueprint overlay on hover */}
        {hovered && project.skills_needed?.length > 0 && (
          <div className="absolute inset-0 bg-primary/10 backdrop-blur-sm flex items-center justify-center p-6 z-10 transition-opacity">
            <div className="text-center">
              <p className="font-mono text-xs tracking-widest text-primary mb-4 uppercase">
                SKILLS NEEDED
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                {project.skills_needed.map((skill) => (
                  <span
                    key={skill}
                    className="font-mono text-xs tracking-wider border border-primary text-primary px-3 py-1"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Category label */}
        <div className="flex items-center justify-between mb-6">
          <span className="font-mono text-[10px] tracking-[0.3em] text-primary uppercase">
            {project.category}
          </span>
          <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>

        {/* Title */}
        <h3 className="text-2xl lg:text-3xl font-black tracking-tight leading-tight text-foreground group-hover:text-primary transition-colors uppercase">
          {project.title}
        </h3>

        {/* Short pitch */}
        {project.short_pitch && (
          <p className="mt-3 text-sm text-muted-foreground leading-relaxed line-clamp-2">
            {project.short_pitch}
          </p>
        )}

        {/* Meta */}
        <div className="mt-6 pt-4 border-t border-border flex items-center justify-between">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="h-3 w-3" />
            <span className="font-mono text-xs tracking-wider">
              {project.city}, {project.country}
            </span>
          </div>
          <span className="font-mono text-[10px] tracking-widest text-muted-foreground uppercase border border-border px-2 py-1">
            {project.stage}
          </span>
        </div>
      </div>
    </Link>
  );
}