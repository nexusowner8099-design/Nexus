import { Link } from "react-router-dom";
import { ArrowRight, Radio } from "lucide-react";
import { motion } from "framer-motion";

const CATEGORIES = [
  "AI & MACHINE LEARNING",
  "FINTECH",
  "HEALTHTECH",
  "EDTECH",
  "E-COMMERCE",
  "SAAS",
  "CLEANTECH",
  "FOODTECH",
  "PROPTECH",
  "LOGISTICS",
  "SOCIAL IMPACT",
  "CREATIVE & MEDIA",
  "CYBERSECURITY",
  "IOT & HARDWARE",
];

export default function HeroSection({ heroImage }) {
  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Entrepreneur sketching blueprints in a brutalist workspace"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-background/90" />
      </div>

      {/* Grid lines decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute left-[10vw] top-0 bottom-0 w-px bg-border opacity-30" />
        <div className="absolute right-[10vw] top-0 bottom-0 w-px bg-border opacity-30" />
        <div className="absolute left-0 right-0 top-1/3 h-px bg-border opacity-20" />
        <div className="absolute left-0 right-0 top-2/3 h-px bg-border opacity-20" />
      </div>

      <div className="relative z-10 px-6 lg:px-[10vw] py-32 lg:py-40">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Left: Typography */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <p className="font-mono text-xs tracking-[0.3em] text-primary mb-6 uppercase">
                <Radio className="inline h-3 w-3 mr-2 animate-pulse-slow" />
                VENTURE ENGINE — LIVE
              </p>
              <h1 className="text-5xl sm:text-7xl lg:text-8xl xl:text-[120px] font-black leading-[0.9] tracking-[-0.05em] text-foreground">
                FIND YOUR
                <br />
                <span className="text-primary">CO-FOUNDER</span>
                <br />
                LOCALLY
              </h1>
              <p className="mt-8 text-lg leading-relaxed text-muted-foreground max-w-md">
                Connect with entrepreneurs in your area who share your vision. 
                Transform solitary ideas into collective powerhouses.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4">
                <Link
                  to="/create"
                  className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:opacity-90 transition-opacity focus:outline-none focus:ring-3 focus:ring-primary"
                >
                  BROADCAST MY IDEA
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/explore"
                  className="inline-flex items-center justify-center gap-2 border border-border text-foreground font-mono text-xs tracking-widest uppercase px-8 py-4 hover:border-primary hover:text-primary transition-colors focus:outline-none focus:ring-3 focus:ring-primary"
                >
                  EXPLORE IDEAS
                </Link>
              </div>
            </motion.div>
          </div>

          {/* Right: decorative grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="hidden lg:block relative h-[500px] overflow-hidden"
          >
            <div className="absolute inset-0 grid grid-cols-3 gap-px opacity-10">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="border border-border" />
              ))}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="font-mono text-[120px] font-black text-primary/10 select-none leading-none tracking-[-0.05em]">N</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}